# Image Tools

> **Design boundary**: keep provider credentials explicit, keep in-pipeline
> acquisition manifest-driven, and treat external image references as authoring
> inputs while delivery writes self-contained SVG previews and native PPTX
> media.

Image tools cover prompt-based AI generation, web image search, image inspection,
and Gemini watermark removal. Native formula authoring belongs to the SVG
pipeline, not the image pipeline.

## Legacy standalone `latex_render.py`

This retained standalone utility renders a user-authored
`images/formula_manifest.json` to PNG. Neither Default nor Quick Generate calls
it, and new projects do not create formula manifests or formula images. The
supported generated-deck path authors a native formula marker in SVG and lets
`svg_to_pptx.py` compile its LaTeX payload to editable PowerPoint OMML.

```bash
python3 scripts/latex_render.py <project_path>
python3 scripts/latex_render.py <project_path> --dry-run
```

Use it only for an explicitly requested external raster workflow. It is not a
compatibility fallback for Keynote, WPS, LibreOffice, or another client.

## `image_gen.py`

Unified image generation entry point.

This script is the **Path A** API/proxy executor for generated images. Default
Generate checks `design_spec.md §I / AI Image Acquisition Path` before manifest
mode: only `api` / `auto` permits Path A; a missing or unknown value fails
closed and returns to Step 4 recovery. Quick Generate has no Design Spec: use
the explicit active-context path when supplied, otherwise `auto` selects the
A → B chain defined in
[`image-generator.md`](../../references/image-generator.md) §7 without asking;
exhausted automation triggers Quick's no-AI replan rather than Offline Manual.
In either profile, `host-native` uses the host image tool directly and an
explicit `manual` choice uses the read-only Markdown sidecar.

```bash
python3 scripts/image_gen.py "A modern futuristic workspace"
python3 scripts/image_gen.py "Abstract tech background" --aspect_ratio 16:9 --image_size 4K
python3 scripts/image_gen.py "Concept car" -o projects/demo/images
python3 scripts/image_gen.py --list-backends
```

Backends are grouped into Core / Extended / Experimental tiers. Run `python3 scripts/image_gen.py --list-backends` for the current list.

`--aspect_ratio` and manifest `aspect_ratio` accept any positive `W:H`, decimals included (`1.85:1`); only a malformed value fails before any request. A ratio never fails a request: each backend outputs the nearest size its model allows and prints `Ratio: requested … -> output …` when the output differs by more than 1%; the manifest keeps the requested ratio and downstream placement crops to it. Backends whose models take free width and height (OpenAI GPT Image 2/2.5, MiniMax, Qwen, Volcengine, Zhipu, Tencent) keep their listed size for a listed ratio and fit any other ratio or tier to the model's official limits (`fit_size` in `backend_common.py`), at the tier's 1:1 pixel budget, clamping a ratio beyond the model's maximum. Backends with a fixed ratio set (Gemini, OpenRouter, fal, BFL, Ideogram, Replicate, Stability, ModelScope, SiliconFlow) send their nearest listed ratio. The default Gemini model, `gemini-nano-banana-2.1`, takes `1:1 1:4 1:8 2:3 3:2 3:4 4:1 4:3 4:5 5:4 8:1 9:16 16:9 21:9` (including extreme ratios, no `3:1`) at `1K/2K/4K`, but not `512px`. `gemini-3.1-flash-image` retains the same ratios and also supports `512px`; `gemini-2.5-flash-image` takes only `1:1 2:3 3:2 3:4 4:3 4:5 5:4 9:16 16:9 21:9` at `1K`.

Backend selection:

```bash
python3 scripts/image_gen.py "A cat" --backend openai
python3 scripts/image_gen.py "A cinematic portrait" --backend minimax
python3 scripts/image_gen.py "A product launch hero image" --backend qwen
python3 scripts/image_gen.py "科技感背景图" --backend zhipu
python3 scripts/image_gen.py "A product KV in cinematic style" --backend volcengine
python3 scripts/image_gen.py "A mountain landscape" --backend tencent
```

Configuration sources:

1. Current process environment variables
2. First `.env` found in this order:
   - Current working directory
   - Skill directory (e.g. `~/.agents/skills/ppt-master/.env`)
   - Clone repo root
   - `~/.ppt-master/.env`

The active backend must always be selected explicitly via `IMAGE_BACKEND`.

Example `.env`:

```env
IMAGE_BACKEND=openai
OPENAI_API_KEY=sk-xxx
OPENAI_MODEL=gpt-image-2.5-sunburst
# Optional proxy
# OPENAI_BASE_URL=http://127.0.0.1:3000/v1
# OpenAI-compatible provider knobs:
# OPENAI_SIZE_PRESET=auto
# OPENAI_RESPONSE_FORMAT=auto
# GPT Image: auto / omit / low / medium / high; xhigh / max only for the 2.5 and 2.6 models
# OPENAI_QUALITY=auto
# Allowed values: png / jpeg / webp; gif only with --gif-frames
# OPENAI_OUTPUT_FORMAT=png
# jpeg/webp only, 0-100
# OPENAI_OUTPUT_COMPRESSION=80
# GPT Image: auto / opaque / transparent (png/webp/gif; gpt-image-2 is preview-only and may return 400)
# OPENAI_BACKGROUND=auto
# auto / low
# OPENAI_MODERATION=auto
```

Example process environment:

```bash
export IMAGE_BACKEND=openai
export OPENAI_API_KEY=sk-xxx
export OPENAI_MODEL=gpt-image-2.5-sunburst
export OPENAI_OUTPUT_FORMAT=png
```

Current process environment wins over `.env`.

OpenAI backend notes:
- `gpt-image-2.5-sunburst` is the default OpenAI model. `gpt-image-2.5-flare` shares its token rates; OpenAI positions Sunburst for editing precision and Flare for fast everyday generation ([models](https://developers.openai.com/api/docs/models/gpt-image-2.5-sunburst)).
- `gpt-image-2.6-sunburst` and `gpt-image-2.6-flare` take the same handling as the 2.5 models below (sizes, `xhigh`/`max`, transparency, no `OPENAI_INPUT_FIDELITY`) and the same token rates, but have no Batch endpoint. Measured on 2026-11-05 at `1536x864`: `quality=medium` (the `1K` default) returned 924 output tokens versus 280 for 2.5; `high` returned 1078 for both ([models](https://developers.openai.com/api/docs/models/gpt-image-2.6-sunburst)).
- Requests are sent with plain `requests.post()` to improve compatibility with
  OpenAI-compatible proxies that block the OpenAI SDK's `httpx` transport.
- With `OPENAI_QUALITY` unset or `auto`, `image_size` also sets quality: `512px` low, `1K` medium, `2K` and `4K` high; set `OPENAI_QUALITY` to decouple them.
- For `gpt-image-2`, `image_size=512px` means a low-quality draft preset, not a literal 512px edge. The model requires both edges to be multiples of 16px, a long:short ratio no greater than 3:1, and total pixels between 655,360 and 8,294,400. The 2.5 and 2.6 models share these rules and sizes; unlisted ratios are fitted to them, so `4:1` at 1K becomes `1776x592` (3:1).
- `OPENAI_BACKGROUND=transparent` is supported by the 2.5 and 2.6 Sunburst and Flare models, including their published snapshots. For `gpt-image-2` it is in preview: a key without preview access gets HTTP 400 `Transparent background is not supported for this model.`, which fails the item without retries. Use PNG (the default), WebP, or GIF (`--gif-frames` on 2.6+), not JPEG.
- `OPENAI_QUALITY=xhigh` and `max` are accepted only for the 2.5 and 2.6 Sunburst and Flare models, including their published snapshots; older GPT Image models retain `auto/omit/low/medium/high`. See the [Images API parameters](https://developers.openai.com/api/reference/resources/images/methods/generate).
- For reference edits, `OPENAI_INPUT_FIDELITY` accepts `high/low` on `gpt-image-1` and `gpt-image-1.5`, but only `low` on `gpt-image-1-mini`. Leave it unset for `gpt-image-2` and the 2.5 and 2.6 models (including snapshots); the API rejects it on 2.6 with HTTP 400, and this backend keeps the omission requirement for 2.5 because its support is not explicitly documented in the [edit API parameters](https://developers.openai.com/api/reference/resources/images/methods/edit).
- OpenAI shut down `gpt-image-1` on 2026-10-23 and DALL·E 2/3 on 2026-05-12, and removes `gpt-image-1-mini`, `gpt-image-1.5` (including `gpt-image-1.5-2025-12-16`) and `chatgpt-image-latest` on 2026-12-01, naming the two 2.5 models as replacements. The backend keeps their size and option handling for OpenAI-compatible providers that still serve them; see [deprecations](https://developers.openai.com/api/docs/deprecations).
- If `OPENAI_OUTPUT_FORMAT=jpeg` or `webp`, a filename without an extension is saved as `.jpg` or `.webp` instead of `.png`; an extension on the filename (every manifest item) still decides the saved format.
- OpenAI-compatible providers that reject OpenAI-specific fields can use `OPENAI_RESPONSE_FORMAT=omit`, `OPENAI_QUALITY=omit`, and `OPENAI_SIZE_PRESET=<preset>`. Valid response formats are `auto`, `b64_json`, `url`, and `omit`; valid size presets are `auto`, `legacy`, `gpt-image`, `gpt-image-2`, and `dall-e-2`.

Example `.env` for Agnes AI through the OpenAI-compatible backend:

```env
IMAGE_BACKEND=openai
OPENAI_API_KEY=your-agnes-key
OPENAI_MODEL=agnes-image-2.1-flash
OPENAI_BASE_URL=https://apihub.agnes-ai.com/v1
OPENAI_SIZE_PRESET=gpt-image-2
OPENAI_RESPONSE_FORMAT=omit
OPENAI_QUALITY=omit
```

Use provider-specific keys only (e.g. `GEMINI_API_KEY`, `OPENAI_API_KEY`). See `.env.example` in clone mode or `${SKILL_DIR}/.env.example` in skill-install mode for the full list per backend.

`IMAGE_API_KEY`, `IMAGE_MODEL`, and `IMAGE_BASE_URL` are intentionally unsupported.

If you keep multiple providers in one `.env` or environment, `IMAGE_BACKEND` must explicitly select the active provider.

Recommendation:
- Default to the Core tier for routine PPT work
- Use Extended only when you need a specific model style
- Treat Experimental backends as opt-in

Example `.env` for MiniMax image backend:

```env
IMAGE_BACKEND=minimax
MINIMAX_API_KEY=your-api-key
# Optional: override base URL (defaults to https://api.minimaxi.com, domestic China endpoint)
# Use https://api.minimax.io for overseas access
# MINIMAX_BASE_URL=https://api.minimax.io
# MINIMAX_MODEL=image-01
```

### Animated GIF output (OpenAI only)

`--gif-frames N` requests 2–16 frames from `gpt-image-2.6-*` (Sunburst / Flare,
including snapshots) or a later 2.x minor. `--gif-frame-ms MS` requires
`--gif-frames` and accepts a positive integer; omission leaves the API default
of 200 ms. Both flags are single-image only and reject `--manifest`,
`--render-md`, and `--list-backends`. Other backends reject GIF requests locally.
The default OpenAI model is 2.5, so select a supported model explicitly or via
`OPENAI_MODEL`.

```bash
python3 scripts/image_gen.py "A looping ripple" --backend openai \
  --model gpt-image-2.6-sunburst --gif-frames 9 --gif-frame-ms 200 --aspect_ratio 16:9
python3 scripts/image_gen.py "Animate the clouds" --backend openai \
  --model gpt-image-2.6-flare --reference-image scene.png --gif-frames 8
```

Generation sends `output_format=gif`, `frame_count`, and the optional
`frame_duration_ms` as JSON; reference edits send the same fields as multipart
form data to `/v1/images/edits`. `OPENAI_OUTPUT_FORMAT` must be unset or `gif`,
and `OPENAI_OUTPUT_COMPRESSION` must be unset. Transparent backgrounds work
with GIF via `OPENAI_BACKGROUND=transparent`.

`size` is per frame. The server's candidate sheets, measured on 2026-11-08,
are listed as columns × rows:

| Frames | Candidate grids |
|---|---|
| 2–8 | 2×4 or 4×2 (always 8 cells) |
| 9 | 3×3 |
| 10–12 | 3×4, 4×3, or 4×4 |
| 13–16 | 4×4 |

For each candidate `(c, r)`, the backend fits the requested ratio using
`fit_size`, then chooses the frame with the largest pixel area. Each edge
is a multiple of 16, width is at most `floor(3840/c)`, height is at most
`floor(3840/r)`, per-frame pixels are at most `8,294,400/(c*r)`, and the
long:short ratio is at most 3:1. **2–8 frames are always billed as an 8-cell
sheet**, so fewer than 8 frames do not cost less at the same frame size.
GIF sizing overrides `OPENAI_SIZE_PRESET`; `--image_size` retains its quality mapping. The console
reports frame size, count, and duration. The API bytes are saved unchanged as
`.gif`, replacing any static image suffix in `--filename` to preserve animation.

## `image_gen.py --manifest` runner and legacy manifest spellings

Each item is written once in its filename's format, whatever the backend returns (a `.jpg` item as JPEG quality 90, a `.png` item as PNG). Validates the file behind every `Generated` row before skipping it, iterates retryable rows with bounded adaptive concurrency, and writes each status atomically; a missing or corrupt file returns to `Failed`, and persistent rate limits end the run as retryable `Failed`. Options: `--concurrency` (default `IMAGE_CONCURRENCY` or 3; halves on rate limit, min 1 — in manifest mode a backend returns a rate limit at once instead of retrying it, so the runner's halving and Retry-After pause act on the first 429; other transient errors keep the backend's own retries), `--image_size`, `--output`/`-o`, `--backend`/`-b`, `--model`/`-m`, `--list-backends`. Interrupting is safe (completed items stay `Generated`); the Markdown sidecar re-renders on completion, or run `--render-md` after an interruption. Configuration: process environment first, then the first `.env` in cwd, the skill directory, the clone root, `~/.ppt-master/.env` — `IMAGE_BACKEND` (required; `--list-backends` shows the set and support tiers), `IMAGE_CONCURRENCY`, provider-specific `{PROVIDER}_API_KEY` / `_BASE_URL` / `_MODEL` (never `IMAGE_API_KEY` / `IMAGE_MODEL` / `IMAGE_BASE_URL`), and for OpenAI-compatible platforms `OPENAI_SIZE_PRESET` (`auto|legacy|gpt-image|gpt-image-2|dall-e-2`), `OPENAI_RESPONSE_FORMAT` (`auto|b64_json|url|omit`), `OPENAI_QUALITY` (`auto|omit|low|medium|high|xhigh|max|standard|hd`; `xhigh/max` only for the two 2.5 models and their snapshots) under `IMAGE_BACKEND=openai`; see `.env.example`. The single-image form `image_gen.py "prompt" --filename …` remains for ad-hoc re-rolls.

**Compatibility**: legacy `type` values read as `background` → `hero_page` + no type, `hero` → `hero_page` + Primitive A, `portrait` → `local` + Primitive B, `typography` → `hero_page` + `embedded` + Primitive C; a missing `page_role` is `local`, a missing `text_policy` is `none` (one aggregate warning per manifest); an existing manifest lacking `deck_rendering` or an item lacking `type` replays its assembled `prompt` verbatim without reconstruction; a legacy `deck_style_anchor` or `deck_palette` never overrides `deck_rendering` / `color_scheme`; legacy `page_role: full_page` reads as `hero_page`.

## `slice_images.py`

Slice a contact sheet with `--grid RxC`, optionally naming the outputs with
`--names` or `--prefix` and choosing their directory with `--output`.
All outputs are checked before any slice is written. An output that resolves to
the source sheet or shares its file identity (including a hard link) is rejected;
choose different names, a prefix, or an output directory. Output symlinks,
including dangling links, are also rejected to preserve both the link and its
referent: remove the output symlink or choose a regular output path before
rerunning. Existing ordinary slices are overwritten, so regenerating a sheet
and rerunning the same names refreshes the files used by the image manifest.
Before slicing, 16-bit grayscale is reduced to 8-bit by retaining each sample's
high byte (`0..65535` → `0..255`), before RGB/RGBA conversion. This uses the
encoded bit depth, never the image's observed brightness range. A PNG grayscale
transparent sample is matched at full depth before reducing the color values.
A sheet that already carries transparency (any pixel with alpha below 20, as
an RGBA host or `OPENAI_BACKGROUND=transparent` output) is cut on its own alpha:
`--trim` and `--alpha` use it, `--bg` is ignored, and `--strict-alpha` checks
only for content reaching a cell edge.

## `image_treat.py`

Create a non-destructive PNG derivative from one bitmap already prepared under
`<project_path>/images/`. Use this only when a slide needs a baked bitmap effect;
crop, mask, rotation, mirror, opacity, shadow, scrim, outline, and overlap remain
native SVG/PPT treatments. This tool does not perform semantic background
removal: use `slice_images.py --alpha --bg <key> --strict-alpha` for flat-color
keys (a pure red/green/blue key also recovers soft alpha and removes spill from
key-dominant blends — including a light element's edge next to the key — taking
the recovered key channel from the strongest other channel so shadows stay grey,
while an opaque foreground of the key's hue stays untouched; thin dark strokes of
that hue can still fringe, so choose the key by hue absence;
strict alpha diagnoses off-key haze from the four 10% key-only margins, allowing
soft shadows and glows on a clean key; a key-hued ground that is not flat —
a gradient, lighting, or texture painted by the image model — is keyed by
key-channel dominance against a local ground estimate instead of one colour,
with a notice to inspect the cut, as is a flat ground farther from every pure
key than drift explains (the measured `--bg` rerun, or the sheet's own ground
without `--bg`) so shadows cast on it clear — a measured ground within drift
of a pure key keeps pure-key recovery — while a flat ground that merely
differs from the stated key is still rejected with the measured colour to rerun
with), an
already prepared RGBA asset or the active host image editor for a standalone cutout, and
[`image-generator.md`](../../references/image-generator.md) §4.4 only for
registered subject/base layers.

```bash
python3 scripts/image_treat.py projects/demo hero.jpg \
  --output hero_soft.png --brightness 0.9 --contrast 1.1 --blur 12

python3 scripts/image_treat.py projects/demo hero.jpg \
  --output hero_duotone.png --duotone "#14213D" "#FCA311"

python3 scripts/image_treat.py projects/demo title_art.png \
  --output title_art_fit.png --fit 920x228
```

Supported operations are brightness, contrast, desaturation/grayscale,
duotone, Gaussian blur, and `--fit WxH` (downscale to fit inside a pixel
box, aspect ratio and alpha preserved; never upscales). They compose in a
fixed order: brightness → contrast → tone treatment → blur → fit. For a cropped
(cover) placement, pass the size the uncropped image takes when it covers the
slot: a 1776x592 source cropped into a 920x228 slot takes `--fit 920x307`;
`--fit 920x228` would leave 684x228 and force an upscale. Desaturation, grayscale, and duotone are
mutually exclusive. At least one option must produce a real change; animated
sources are rejected rather than reduced to one frame, while a camera
multi-picture JPEG (MPO) contributes its primary frame.
Before treatments, 16-bit grayscale uses the same depth normalization as
[`slice_images.py`](#slice_imagespy), including for a `--fit`-only derivative.

Both input and output are bare filenames directly under `images/`; output must
be a new `.png` file, or a new `.jpg` file when the source is opaque (a
photograph downscaled with `--fit` keeps its weight in check that way; a
source with transparency is refused for `.jpg`). The tool keeps the EXIF-corrected display dimensions,
leaves any alpha mask unchanged, and never overwrites the source or an existing
derivative. If `images/image_sources.json` contains the source filename, the
new record inherits that legal provenance and records `derived_from` plus the
ordered `treatments`. Run `analyze_images.py` after all planned derivatives are
ready so the inventory reflects the files that SVG authoring will consume.

## `image_ocr.py`

OCR helper for the [Image to PPTX](../../workflows/profiles/image-to-pptx.md)
profile. `rapidocr` and `onnxruntime` are optional (about 170 MB with their
OpenCV dependency) and are not installed by `requirements.txt`; `scan` prints
the install command and exits `2` when they are missing.

```bash
pip install rapidocr onnxruntime
python3 scripts/image_ocr.py scan <project_path> images/source-pages/01.png [...] --canvas 1280x720
python3 scripts/image_ocr.py merge-base <project_path> --page 01 --inpainted images/01_inpainted.png \
  --out images/01_base.png [--pad 6]
python3 scripts/image_ocr.py text-layer <project_path> --page 01 --base images/01_base.png \
  --out svg_output/01_cover.svg --font "Microsoft YaHei, Arial" [--title-font "SimSun, Cambria"] \
  [--lang zh-CN] [--page-role cover]
```

`scan` writes `analysis/ocr/<page-stem>.json` per page image and prints one
line per block (`?` marks a block whose lowest line confidence is below 0.9).
Coordinates are canvas pixels: `--canvas` must be the deck canvas, and the
scale is `canvas width / page pixel width`. Lines are merged into one block
when they share a left edge (within 0.6 line heights), a height (within 25%),
an ink color (RGB distance below 64), and a vertical gap of at most 0.9 line
heights; labels, notes, and body copy with different ink therefore stay
separate blocks.

| Block field | Meaning |
|---|---|
| `id` | Stable `tNN` id in reading order; becomes the SVG group id |
| `lines[]` | One entry per OCR line: `text`, `score`, `x`, `y`, `w`, `h` (canvas px). `text-layer` places exactly these line strings |
| `text` | The joined lines, for reading only; editing it changes nothing |
| `font_size` | 0.97 × median of line width ÷ advance units (CJK 1.0 em, capitals 0.68, other letters and digits 0.54, punctuation 0.36) over lines of at least four units, else line height ÷ 1.4 |
| `color` | Mean ink color of the first line (pixels farther than 60% of the maximum distance from the line box's border median) |
| `skip` | Absent by default; set `true` for text that belongs to an image (photo signage, product print, logo lettering) |

`merge-base` composites a text-removed image (from `image_gen.py
--reference-image` or a host's native editor) into the source page: inside
each unskipped OCR line box, grown by `--pad` canvas px and feathered by 2 px,
it takes the inpainted pixels; everywhere else it keeps the source pixels, so
photos, graphics, and rules outside the text boxes stay byte-identical to the
page image. Each `--layer <png>` (repeatable; RGBA or a flat magenta/green
key) adds that layer's opaque area, grown by `--pad`, to the inpainted region,
so objects removed from the base for their own layer do not come back from the
source. When the page image is narrower than the canvas, nothing is merged: the
generated image is written whole at its own resolution, because upscaled
source pixels would be blurrier. Run it after review, because `skip` blocks
keep their source pixels. A rule or shape the inpainting extended into a text
box stays in the merged base; the removal prompt prevents that, not the merge.

With OCR installed, `merge-base` then re-reads the written base: every OCR line
(score at least 0.6, containing a letter, digit, or CJK character) whose center
falls inside a removal box is printed under `Residue:` and the command exits
`3`; the file is still written. Without OCR it prints that the check was
skipped and exits `0`.

**Review contract**: `scan` rewrites the JSON, so run it before review and never after. Correct a misread by editing that line's `lines[].text`
(OCR drops spaces around `+`, `·`, and Latin words and confuses `I` / `l`);
mark image-owned text `skip: true`; keep the line count so line positions
stay registered. `text-layer` then writes one SVG: a full-canvas
`data-pptx-role="background"` image of the text-free base, and one root group
per unskipped block with one `<text>` whose later lines are positioned
`<tspan>` rows. Baselines are `line top + line height / 2 + 0.36 × font size`;
the largest block (and only the first within 85% of it) takes `--title-font`
and the group id `title`. When the stack's first family is monospace (Consolas, Courier, Menlo, `*Mono*`), `text-layer` recomputes each block's size with 0.55 em per non-CJK glyph instead of using `font_size`. Each group's `data-pptx-bounds` spans the estimated
glyph extent plus a 4 px margin, widened rightward to the nearest zone on its
right or to 8 px inside the canvas; remaining overlaps are split at the
midpoint, top/bottom only for genuinely stacked zones and left/right otherwise. The generated page runs through the Quick final checker
like any page; weight, emphasis runs, and alignment other than left-aligned
are not inferred and are added by hand when the source shows them.

## `image_layers.py`

Layer helpers for the [Image to PPTX](../../workflows/profiles/image-to-pptx.md)
profile; Pillow and numpy only.

```bash
python3 scripts/image_layers.py check <project_path> --page-image images/source-pages/01.png \
  --layer images/01_plate.png [--occlusion-mask images/01_occlusion.png] [--ratio 0.8]
python3 scripts/image_layers.py diff-matte <project_path> --page-image images/source-pages/01.png \
  --base images/01_base.png --out images/01_subject.png [--ocr analysis/ocr/01.json] [--threshold 60]
python3 scripts/image_layers.py mono-matte <project_path> --plate images/01_plate_key.png --key "#FF00FF" \
  --box 44.7 25.1 72.1 70.2 --out images/01_logo.png [--fill "#FFFFFF"] [--canvas-width 1280]
```

`check` compares the layer's opaque pixels with the page at the same position,
on a 640-px-wide copy, and at every shift of 5 and 10 px in x and y. It prints
the origin difference, the best shifted difference, and the best offset in page
pixels, then exits `0` (`Registered`) when the origin difference is at most
`--ratio` times the best shifted one, otherwise `3`. Opacity comes from real
alpha whenever any pixel has alpha below 20, regardless of its share of the
image; pixels with alpha above 200 enter the opacity mask shared with
`merge-base`. When no pixel has alpha below 20, flat `#FF00FF` or `#00FF00`
key detection remains active, including near-opaque RGBA inputs such as an
image whose alpha is uniformly 250. When a layer completes parts hidden behind
upper objects in the page, supply `--occlusion-mask`: a grayscale image at the
canonical page dimensions, with nonzero pixels marking those actual occluders
and zero pixels elsewhere. Only originally visible layer pixels are compared,
and shifted samples landing behind an occluder are excluded too. When resizing,
samples whose bicubic kernel support touches an occluder are also excluded,
so thin occluders and their resampling fringes cannot enter the score. Registration
uses the same ratio and shifts; without a mask it compares all opaque pixels
and does not infer occlusion from color differences. A wrong-size mask, no
visible opaque pixels, or no shifted comparison pixels exits `1` with a repair
hint. The mask is comparison evidence only; the complete layer is unchanged,
and the page assembly must still place the occluders above it.

`diff-matte` writes an RGBA layer from the page's own pixels: a pixel is kept
when its RGB distance to the resized base exceeds `--threshold`, outside the
reviewed OCR text boxes when `--ocr` is given; the mask is closed by 3 px and
feathered by 0.8 px. It needs no generator and is registered by construction,
but it is limited to the page's resolution, and it loses parts whose color
matches the background behind them.

`mono-matte` cuts one single-color graphic (a white logo or wordmark) from a
raw flat-key plate, before keying: inside `--box` (canvas px, scaled to the
plate), each low channel (below 128 in the key: G for `#FF00FF`, R and B for
`#00FF00`) has its own key value subtracted and negative differences clipped
to zero. Alpha is the minimum of those differences, normalized so the 99th
percentile is opaque, and every pixel takes `--fill`. Nonzero low-channel keys
such as `#FF40FF` and `#20FF20` therefore leave zero alpha on the key field.
Key color cannot bleed into the
edges, and interior gaps the generator painted with the key become
transparent. It prints the placement box; a key that lacks no channel exits `1`.

## `analyze_images.py`

Analyze objective image-file facts in a project directory before writing the
design spec or authoring SVG.

```bash
python3 scripts/analyze_images.py <project_path>/images
```

The tool does not resolve a canvas or recommend a left/right, top/bottom, or
other slide layout. Its atomic CSV records EXIF-corrected native dimensions and
`AspectRatio`, the objective aspect-ratio category, optional source
`SourceDisplayRatio`, format, actual transparent-pixel presence, usage count,
and bitmap/vector capability facts. The usage count (`Uses` in the table) is
how many source occurrences the import manifest recorded for the asset; it is
not a count of SVG references and does not find unused assets. An empty folder rewrites a header-only
report; unreadable supported files still refresh the report and produce a
non-zero exit.

Use this as the default factual inventory; it does not perform semantic image
understanding or choose composition. Generate planning follows the Strategist's
context-first boundary: source context, captions / alt text / titles, filenames,
user notes, and existing resource records come first. Only an already-selected
provided/web asset whose focal-safe crop, overlay contrast, or quiet region
remains materially ambiguous may be inspected for that placement; this never
reopens selection or provenance, never bulk-opens the image folder, and never
restores routine readback of AI-generated images.

## `image_search.py`

Zero-config web image search across openly-licensed providers. Sister tool to `image_gen.py` — used when the resource list row has `Acquire Via: web`.

```bash
python3 scripts/image_search.py "offshore wind farm" \
  --filename cover_bg.jpg --slide 01_cover \
  --orientation landscape -o projects/demo/images
```

For multiple web rows, `--batch images/image_queries.json` searches them concurrently (modest default, `--concurrency N` / `IMAGE_SEARCH_CONCURRENCY` to tune) instead of one call per row — the web sister of `image_gen.py --manifest`. Schema and status semantics: [`image-searcher.md`](../../references/image-searcher.md) §5.

Providers (Pexels / Pixabay are tried first when keyed; Openverse and Wikimedia are zero-config fallbacks):

| Provider | Config | Strength |
|---|---|---|
| `pexels` | recommended: `PEXELS_API_KEY` | modern stock photography, people, workplace, lifestyle |
| `pixabay` | recommended: `PIXABAY_API_KEY` | broad type coverage including photos and illustrations |
| `openverse` | zero-config | fallback aggregator: Wikimedia + Flickr + museums + rawpixel |
| `wikimedia` | zero-config | educational, scientific, geographic, historical |

Default search chain (when `--provider` is unset): configured Pexels, configured Pixabay, Openverse, then Wikimedia. Missing keyed credentials are silently skipped. Keyed providers broaden stock-photo coverage but are optional; zero-config providers remain valid.

`image_search.py` uses the same `.env` lookup order as `image_gen.py`, so skill installs can keep `PEXELS_API_KEY` / `PIXABAY_API_KEY` in `~/.ppt-master/.env`.

Query guidance:

Keep the Design Spec §VIII `Reference` as the full visual/crop intent; write a separate concise provider query for this CLI. Start with the shortest phrase that preserves identity, but retain exact multi-word names and necessary disambiguators beyond four words.

For exact entities with multiple common names, add repeatable `--query-variant`
values (batch: `query_variants`) for materially different official
translations, spellings, aliases, or Chinese names. Results are aggregated and
deduplicated before ranking.

| Case | Pattern |
|---|---|
| Generic stock concept | `boardroom meeting` |
| China-specific landmark | Precise official place/identity name plus necessary geography |
| Avoid | Negative prompt wording such as `not tourist snapshot` |

License filter:

- **Default**: search all providers with `cc0,pdm,pexels,pixabay,cc by,cc by-sa` allowed together. The chosen image may be `no-attribution` or `attribution-required`; Executor adds an inline credit only when needed.
- `--strict-no-attribution` restricts the search to `cc0,pdm,pexels,pixabay` — useful for full-bleed hero images or templates that cannot host a credit element.

Pin a provider, refuse attribution, or override the manifest path:

```bash
# Pin Wikimedia
python3 scripts/image_search.py "Olympics opening ceremony" \
  --filename event.jpg --provider wikimedia \
  --orientation landscape -o projects/demo/images

# Strict mode — refuse CC BY / CC BY-SA
python3 scripts/image_search.py "abstract gradient" \
  --filename hero.jpg --strict-no-attribution \
  -o projects/demo/images
```

Suitability & manual replacement (a web top hit is metadata-relevant, not guaranteed visually right):

- By default only the best match is downloaded, plus a downscaled review copy at `images/.review/<stem>.jpg` (the placed asset stays full-resolution). A downloaded camera multi-picture JPEG (MPO, common among Commons originals) is rewritten as its primary frame before validation so every later consumer sees a single-frame JPEG. An original above Pillow's decompression-warning size (about 89.5 megapixels) is first reduced by the smallest power of two that fits, keeping format, EXIF, and ICC data, so later readers neither warn nor decode hundreds of megabytes.
- For exact subjects (landmarks, people, companies, products), use `--require-terms` or batch `required_terms` so visually plausible but wrong metadata is rejected before ranking. Example: `--require-terms Chongqing --require-terms "Jiefangbei|Liberation Monument"`. Keep proper-name / geography anchors; do not broaden to generic terms like `canyon`, `stone pillar`, or `ancient town` just to improve coverage.
- When the current Generate agent can inspect images, use `--save-candidates`. The tool saves only the first ranked page of review-eligible provider previews (**8 by default**), writes `candidates/<stem>/review_sheet.jpg`, and leaves the target image and `image_sources.json` untouched. Standalone CLI use remains best-only unless this flag is explicit.
- Compare the thumbnail set against the active Reference/Crop Policy. Only after one passes, run `--promote candidate_03.jpg --filename <name>.jpg`; this downloads and validates exactly that original. In batch mode, pass the same `--batch images/image_queries.json` so `Needs-Selection` becomes `Sourced`.
- If no thumbnail passes and `has_more_candidates` is true, fetch `--candidate-page 2` with the same query and filename — the pool's saved `required_terms`, `query_variants`, orientation, and minimum dimensions are inherited unless given again, and a changed query is refused as a page continuation (start a new page-1 pool instead). In batch mode pass `--candidate-page 2` to rerun every `Needs-Selection` row at that page, or set one row's `candidate_page` to `next_candidate_page` and reset only it to `Pending`. Candidate numbering continues at 9, earlier pages stay in `candidates.json` (`saved_pages`) so any saved thumbnail remains promotable, and no original is downloaded. Only after the pool is exhausted should you materially change the identity wording, viewpoint, translation, alias, or disambiguator and generate a fresh pool.
- Without multimodal inspection, omit `--save-candidates`. Best-only mode rejects visual-verification-required near matches, accepts only a strict metadata candidate, downloads one original, and records `selection_method: metadata-ranked`; if metadata cannot prove the entity or the active visual requirement, use `Needs-Manual` rather than claiming visual confirmation.
- `--from-url <url> --filename <name>.jpg` downloads a user-chosen image URL and replaces the target (recorded `license_tier: manual`) — the model-agnostic manual path; works even without a multimodal model.

Full review / escalation flow: [`image-searcher.md`](../../references/image-searcher.md) §5.

Output:

- `--save-candidates`: thumbnail-only `candidates/<stem>/candidates.json`, at most 8 provider previews by default, and `review_sheet.jpg`; no target image or provenance entry. `--candidate-page N` advances through the ranked pool while keeping earlier pages' entries in `candidates.json`; `--max-candidates 0` explicitly dumps all candidates for exceptional debugging
- Best-only / `--promote`: one original saved to the specified output directory (auto-converts webp → jpg via Pillow when the filename extension demands)
- Best-only / `--promote`: `image_sources.json` manifest with full provenance (provider, license, license_tier, author, source URL, dimensions, attribution_text)
- Manifest is idempotent on `filename` and written atomically; damaged existing provenance blocks replacement

Allowed licenses (default): CC0, Public Domain, Pexels License, Pixabay Content License, CC BY, CC BY-SA. Auto-rejected: CC BY-NC, CC BY-ND, CC BY-NC-SA, CC BY-NC-ND, all rights reserved, unknown.

The full role-level reference (intent → query translation, on-slide attribution contract) is in [`references/image-searcher.md`](../../references/image-searcher.md).

### `image_search.py` parameters

| Parameter | Default | Description |
|---|---|---|
| `query` (positional, required) | — | Simplified internally |
| `--query-variant` | — | Repeatable alias/translation; batch rows use `query_variants` |
| `--filename` (required) | — | Output filename matching the resource list |
| `-o / --output` | `.` | Output directory; manifest defaults to `<output>/image_sources.json` |
| `--slide`, `--purpose`, `--orientation` | `""`, `""`, `any` | Recorded slide id; `background` / `hero` / `side` / `accent`; `landscape` / `portrait` / `square` |
| `--min-width / --min-height` | `1200 / 800` | Downloaded-pixel floors; `--from-url` honors explicit lower overrides |
| `--provider` | chain | Pin one provider |
| `--strict-no-attribution` | off | Refuse CC BY / CC BY-SA |
| `--require-terms` | — | Repeatable identity gate; comma separates groups, `A|B` aliases |
| `--save-candidates` | off | Thumbnail mode: one ranked page of previews plus `review_sheet.jpg`, no original |
| `--max-candidates` | `8` | Page size; `0` = complete pool, debugging only |
| `--candidate-page` | `1` | Ranked page; page 2 starts at rank 9. Single-query continuation inherits the saved pool request; batch reruns every `Needs-Selection` row at that page |
| `--promote <candidate>` | — | Download exactly one selected original, enforce gates, write provenance |
| `--from-url <url>` | — | Manual replacement recorded as `license_tier: manual`; works without vision |
| `--manifest <path>` | `images/image_queries.json` | Override the manifest path |

### Batch runner and ranking

Required per item: `filename`, `query`, `status`; optional: `query_variants`, `candidate_page`, `slide`, `purpose`, `orientation`, `provider`, `strict_no_attribution`, `min_width`, `min_height`, `required_terms`. The runner revalidates every `Sourced` row against its file, dimensions, and manifest entry (drift → `Failed`), then searches all `Pending` / `Failed` rows concurrently (default concurrency 3, `--concurrency N` or `IMAGE_SEARCH_CONCURRENCY`; `1` for strict pacing on rate-sensitive free providers). Thumbnail mode writes `Needs-Selection` with `candidate_page`, `candidate_count`, `candidate_total`, `has_more_candidates`, `next_candidate_page`, and the `review_sheet` path, creating no image or provenance; to see the next page for one row set its `candidate_page` to `next_candidate_page`, reset only that row to `Pending`, and rerun; `--candidate-page N` on the batch run advances every `Needs-Selection` row at once. A positional query is rejected in batch mode rather than ignored. Promoting with the same `--batch` manifest moves the row to `Sourced`. Provider failures stay retryable `Failed`; clean exhaustion becomes `Needs-Manual`; status is saved after each completion.

**Ranking** orders provider metadata, never pixels, and must not be tuned into a taste engine: hard-reject invalid licenses and zero relevance; in best-only mode reject any candidate missing a `required_terms` group; in thumbnail mode keep strict matches first and admit a near match only when exactly one group is missing and the finding query still has strong relevance (marked `identity_evidence: visual-verification-required`, never auto-promoted); then metadata-verified identity in the title outranks a URL-only match; concrete query tokens match whole ASCII tokens (`office` ≠ `officer`) and dominate generic words; orientation is a small penalty, no-attribution a small bonus, pixel count capped so a huge weak match cannot beat a smaller accurate one.

### `image_sources.json` format

Each successful download appends or replaces one entry keyed on `filename`; the file is written atomically and is idempotent, and an unreadable existing manifest blocks the write.

```json
{
  "license_verification": "provider metadata used; manual review recommended for external delivery",
  "generated_at": "2026-05-01T12:17:59.856275Z",
  "items": [ {
    "filename": "team.jpg", "slide": "03_team", "purpose": "Leadership photo",
    "search_query": "executive boardroom meeting", "matched_query": "leadership team boardroom",
    "selection_method": "metadata-ranked", "orientation": "landscape",
    "provider": "openverse", "stage": "all",
    "title": "Untitled", "author": "",
    "source_page_url": "https://www.rawpixel.com/...", "download_url": "https://...",
    "license_name": "CC0", "license_url": "https://creativecommons.org/publicdomain/zero/1.0/",
    "license_tier": "no-attribution", "attribution_required": false,
    "width": 1024, "height": 683,
    "metadata_dimensions": { "width": 4800, "height": 3200, "note": "upstream-reported size; actual downloaded file is smaller (likely a preview)" },
    "attribution_text": "team.jpg — \"Untitled\" via Openverse — license: CC0 (...)",
    "status": "sourced"
  } ]
}
```

`matched_query` is the query or variant that found the asset; `selection_method` is `visual-thumbnail` after a reviewed promotion or `metadata-ranked` for the strict path; `width` / `height` are measured from the saved file (use them for layout) while `metadata_dimensions` appears only when the upstream claim differs; `license_tier` drives Executor's attribution; `attribution_text` is the canonical credit source, compressed only through §7's grammar; `stage` is `all` or `no-attribution-only`.

---

### Failure handling

Extends [`image-base.md`](../../references/image-base.md) §3. No candidates from any provider or stage → `Needs-Manual` (suggest a more precise query or another provider; rerun without `--strict-no-attribution` only when the page may carry credit). No acceptable image on the current page with `has_more_candidates` → fetch `next_candidate_page` without changing the query or downloading. A page past `candidate_total` → pool exhausted, add a variant or move to the manual boundary. Some previews fail while another qualifies → keep the set. Every preview fails, or a provider/network failure remains → `Failed`, retried by a later batch. A promoted original fails its download/readability/dimension gate → stay `Needs-Selection` and select another or change the query. A best-only download 403/404 → the dispatcher falls to the next ranked candidate. A keyed provider without a key → skipped. CLI exit: a prepared `Needs-Selection` set returns `0`; `Failed` or `Needs-Manual` returns `1`.

---

## `gemini_watermark_remover.py`

Remove Gemini watermark assets after manual download.

```bash
python3 scripts/gemini_watermark_remover.py <image_path>
python3 scripts/gemini_watermark_remover.py <image_path> -o output_path.png
python3 scripts/gemini_watermark_remover.py <image_path> -q
```

Notes:
- Requires `scripts/assets/bg_48.png` and `scripts/assets/bg_96.png`
- Best used after downloading “full size” Gemini images

Dependencies:

```bash
pip install Pillow numpy
```
